
export default function App() {
  return (
    <div className="min-h-screen bg-yellow-50 text-center p-10">
      <h1 className="text-4xl font-bold text-orange-600 mb-4">Тёплый контакт</h1>
      <p className="text-lg text-gray-700">Готовый лендинг. Работает без боли. Просто запускай!</p>
    </div>
  );
}
